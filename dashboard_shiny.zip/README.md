# dashboard_shiny

To start the project execute everything in app.r :)